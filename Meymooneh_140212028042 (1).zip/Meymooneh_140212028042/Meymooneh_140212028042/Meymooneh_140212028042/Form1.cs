﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace sarashaabani_140212028005
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string postfix = textBox1.Text.Trim();
            string infix = ConvertPostfixToInfix(postfix);
            textBox2.Text = infix;
        }
        private string ConvertPostfixToInfix(string postfix)
        {
            Stack<string> stack = new Stack<string>();
            string[] tokens = Regex.Split(postfix, @"\s+");
            foreach (string token in tokens)
            {
                if (IsOperatorr(token))
                {
                    string operand2 = stack.Pop();
                    string operand1 = stack.Pop();
                    string expression = $"({operand1} {token} {operand2})";
                    stack.Push(expression);
                }
                else
                {
                    stack.Push(token);
                }
            }
            return stack.Pop();
        }
        private bool IsOperatorr(string token)
        {
            return token == "+" || token == "-" || token == "*" || token == "/" || token == "^";
        }
        private int GetPrecedence(char op)
        {
            switch (op)
            {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                case '^':
                    return 3;
                default:
                    return 0;

            }
        }
        private bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
        }
        private string InfixToPostfix(string infix)
        {
            Stack<char> stack = new Stack<char>();
            string postfix = "";
            foreach (char token in infix)
            {
                if (char.IsLetterOrDigit(token))//اگر اپراتور است
                {
                    postfix += token;
                }
                else if (token == '(')//اگر پرانتز باز است
                {
                    stack.Push(token);
                }
                else if (token == ')')//اگر پرانتز بسته است
                {
                    while (stack.Count > 0 && stack.Peek() != '(')
                    {
                        postfix += stack.Pop();//حذف پرانتز باز
                    }
                    stack.Pop();
                }
                else if (IsOperator(token))//اگر اپراتور است
                {
                    while (stack.Count > 0 && GetPrecedence(stack.Peek()) >= GetPrecedence(token))
                    {
                        postfix += stack.Pop();
                    }
                    stack.Push(token);
                }
            }
            while (stack.Count > 0)//حذف باقی مانده اپراتورها
            {
                postfix += stack.Pop();
            }
            return postfix;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string infixExpression = textBox3.Text;
            string postfixExpression = InfixToPostfix(infixExpression);
            textBox4.Text = postfixExpression;
        }
    }
}
